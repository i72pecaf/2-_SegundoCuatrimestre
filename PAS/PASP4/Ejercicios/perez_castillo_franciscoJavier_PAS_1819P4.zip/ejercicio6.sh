#!/bin/bash

if [ $# -ne 1 ]
then
	echo "Error en el numero de argumentos, solo se debe de introducir una cadena de texto"
	exit 1
fi


