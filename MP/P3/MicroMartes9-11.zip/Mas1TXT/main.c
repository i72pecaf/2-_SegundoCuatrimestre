#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"



int main(){
	int num;
	struct alumno aux;
	printf("Indique la edad a incrementar\n");
	scanf("%i", &num);

	
	sumar(aux, num);



return 0;


}