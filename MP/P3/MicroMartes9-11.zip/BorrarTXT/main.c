#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"



int main(){
	int num;
	struct alumno aux;
	printf("Indique la edad a incrementar\n");
	scanf("%i", &num);

	
	borrar(aux, num);



return 0;


}